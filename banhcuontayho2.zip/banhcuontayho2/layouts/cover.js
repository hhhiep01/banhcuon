import Image from "next/image";
import BreakLine from "../break-line";
import NavigationBar from "./navigation-bar";
function Cover(){
    return <>
        <div className=" min-h-dvh bg-center bg-no-repeat bg-[url('/../image/banner.png')] bg-[length:100vw_100vh]">
        </div>
    </>
}
export default Cover;